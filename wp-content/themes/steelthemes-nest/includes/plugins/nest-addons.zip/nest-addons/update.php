<?php
 // update
if(!defined('ABSPATH')){
	die('-1');
} 

 
Class Nest_update{
// check updates
}
 
new Nest_update();












 

